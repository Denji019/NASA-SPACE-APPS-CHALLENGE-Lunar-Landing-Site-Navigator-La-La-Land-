# SELENE-3D v17: final package

## What is in this ZIP

| File | What it is |
|---|---|
| `SELENE-3D_Lunar_Site_Explorer_v17.html` | The final app. Identical to the v17 you sent except for one bug fix (see "Change to v17"). |
| `data/1_NASA_LOLA_polar_sites_PSR_distance.csv` | Distance to the nearest permanently shadowed region (PSR) for the listed south-polar sites. Fills **Water-ice access**. |
| `data/2_Published_surface_temperatures.csv` | Published surface temperatures for Apollo 15, Apollo 17 and Chandrayaan-3, plus the LCROSS impact point as a reference. Fills **Temperature**. |
| `data/optional/NASA_LOLA_polar_sites_slope_roughness_100m.csv` | NASA 100 m-baseline slope and roughness for the same polar sites. Read the caveat before loading. |
| `data/optional/NASA_LOLA_PSR_boundaries_ge10km2_poleward_84S.csv` | Outlines of the 95 PSRs of 10 km² or more that reach poleward of 84°S, so any clicked point near the pole gets a PSR result. Read the caveat before loading. |

## How to run

1. Open `SELENE-3D_Lunar_Site_Explorer_v17.html` in Chrome or Edge. It needs internet for three.js (CDN), Wikipedia site notes and JPL Horizons.
2. Click **Compare**, pick two sites, then choose a factor such as **Water-ice access**.
3. In the Point A panel click **Load source data for both points** and select both files in `data/` (multi-select works). The app reads them in the browser; nothing is uploaded.

The app does not remember loaded files after a page reload, so load them again each session.

## What the data fills

| Compare factor | After loading `data/1_…` and `data/2_…` |
|---|---|
| Water-ice access | Filled for IM-2 · Mons Mouton, Shackleton rim, Cabeus, Haworth, Faustini, Malapert massif, Nobile rim. Other sites still say "Awaiting PSR boundary data". |
| Temperature | Apollo 15 and Apollo 17 show an average; Chandrayaan-3 shows a maximum. Other sites still await data. |
| Data confidence | Lists the loaded files. |
| Landing hazards | Still empty. No published boulder or rock-abundance figure exists for these exact sites that I could verify. |
| Traversability | Still empty. It needs a specific route. |
| Communication quality | Still empty. It needs a mission radio link budget. |

Values for the listed polar sites, from the NASA LOLA PSR map:

| Site | Result | Nearest PSR larger than 1 km² |
|---|---|---|
| IM-2 · Mons Mouton | 9.660 km outside | 2.4 km² |
| Malapert massif | 10.576 km outside | 1.4 km² |
| Nobile rim | 7.603 km outside | 6.3 km² |
| Shackleton rim | Inside, 5.539 km from the edge | 233.4 km² (Shackleton) |
| Cabeus | Inside, 0.265 km from the edge | 46.3 km² |
| Haworth | Inside, 12.963 km from the edge | 1010.0 km² (Haworth) |
| Faustini | Inside, 2.641 km from the edge | 660.2 km² (Faustini) |
| IM-1 · Malapert A | Left blank | The site is 4 km from the product's edge at 80°S, so a nearer PSR to the north cannot be ruled out. |

"Outside" distances are to the nearest PSR larger than 1 km². Smaller shadowed patches exist and may be closer.

The "Shackleton rim" coordinates in the app (89.54°S, 129.78°E) are inside the crater's shadow, not on the sunlit rim.

## Caveats for the optional files

**Slope and roughness (100 m baseline).** Loading this replaces "Local slope" and "Local roughness" for the eight polar sites with NASA values measured over a 100 m window. Non-polar sites keep the app's built-in values, which are measured over kilometres. The two are not comparable, so use this file only when both compared points are polar sites. The panel caption will still describe the built-in data.

**PSR outlines.** Use only for points poleward of about 84°S.
- The file covers the south pole only. For a point elsewhere, the app would report the distance to the south pole's PSRs, which is not the nearest PSR.
- It holds PSRs of 10 km² or more, with outlines simplified to about 250 m.
- Inside/outside results matched the full-resolution NASA data at all eight test points. Distances are approximate: the app measures them in a flat local frame, and one test point (IM-2) read 8.7 km where the exact figure is more than 10.7 km.
- When `data/1_…` is also loaded, its exact site values take priority at the listed sites.

## Sources

| Data | Source |
|---|---|
| PSR distances and outlines | NASA GSFC Planetary Geodesy Data Archive, product 90, file `LPSR_80S_20MPP_ADJ_1km2` (1,531 PSRs larger than 1 km², from the 20 m/px LOLA PSR map). Barker et al. 2023, *Planetary Science Journal* 4:183, doi:10.3847/PSJ/acf3e1. https://pgda.gsfc.nasa.gov/products/90 |
| Slope and roughness | Same product: `LDRM_80S_1000MPP_ADJ_SLP_100M.TIF` and `LDRM_80S_1000MPP_ADJ_ROUGH_100M.TIF` (1 km/px grids of plane-fit slope and height spread for a 100 m baseline). |
| Apollo 15 and 17 mean surface temperature (207 K, 216 K) | Langseth & Keihm 1977, Lunar Heat-Flow Experiment final report, Table 1. https://ntrs.nasa.gov/citations/19780010035 |
| Chandrayaan-3 peak surface temperature (355 K ± 0.5 K) | Durga Prasad et al. 2025, *Communications Earth & Environment*, doi:10.1038/s43247-025-02114-6. ISRO summary: https://www.isro.gov.in/ISRO_EN/India_Bags_Credit_First-Ever_In-Situ_Measurement.html |
| LCROSS impact site annual average (37 K) | Paige et al. 2010, *Science* 330:479, doi:10.1126/science.1197135. https://www.eurekalert.org/news-releases/648084 |
| LCROSS impact coordinates | Marshall et al. 2012, "Locating the LCROSS Impact Craters", arXiv:1103.1687 |

## How the NASA values were derived

- The PSR polygon table (29.6 MB) was read on 15 November 2026. Polygon areas recomputed from the coordinates match the table's own `area_km2` column to within 1.4%, which is the expected projection scale difference at 80°S.
- Each site was converted to the product's south polar stereographic coordinates (sphere radius 1737.4 km). Distance is to the nearest polygon edge, corrected for map scale at the site. "Inside" uses all rings, so sunlit holes inside a PSR are respected.
- Slope and roughness are the value of the 1 km pixel containing the site.
- Every row carries its source, source URL and notes in extra columns. The app ignores those columns.

## Change to v17

One bug fixed in the Compare module, in `solarAnalysis`: at each sunrise the code read the new sample's solar flux before setting it, so **Sun & power → Ideal exposure** showed `NaN kWh/m²/day`. The flux is now set first. Nothing else in the file was changed. Checked in headless Chrome: Apollo 15 now reads 9.27 kWh/m²/day, and no console errors appear with the data loaded.

## Not included

The `lunar-site-comparison` folder held an old v3 build (already merged into v17) and an interface prototype whose numbers are labelled as illustrative mock data. Neither is used by v17, so neither is in this package.
